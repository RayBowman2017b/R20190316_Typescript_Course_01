({
    optimizeCss:    "standard",
    cssIn:          "../app/public/css/main.css",
    out:            "../app/public/css/app.css"
})
