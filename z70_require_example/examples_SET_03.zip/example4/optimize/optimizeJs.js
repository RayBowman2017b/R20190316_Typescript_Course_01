({
	paths: {
		jquery:		"empty:",
		ko:		    "empty:",
		bootstrap:	"empty:"
	},
	baseUrl:    "../app/public/js",
	out:        "../app/public/js/app.js",
	name:       "load",
	optimize:	"uglify"
	//optimize:	"none"
})
