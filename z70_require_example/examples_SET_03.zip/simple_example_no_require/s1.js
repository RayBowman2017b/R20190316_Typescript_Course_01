var s1 = (function() {
	console.log("s1");
	return { text: 'test' };
})();