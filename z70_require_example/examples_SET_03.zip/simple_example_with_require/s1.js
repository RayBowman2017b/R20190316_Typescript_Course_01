define(function() {
	console.log("s1");
	return { text: 'test' };
});