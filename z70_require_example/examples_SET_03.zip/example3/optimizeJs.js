({
	paths: {
		jquery:		"empty:",
		ko:		    "empty:",
		bootstrap:	"empty:"
	},
	baseUrl:    "./",
	out:        "./app.js",
	name:       "load"
})
