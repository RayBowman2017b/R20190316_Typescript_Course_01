({
    optimizeCss:    "standard",
    cssIn:          "./main.css",
    out:            "./app.css"
})
