some examples that use requirejs on the server side.
