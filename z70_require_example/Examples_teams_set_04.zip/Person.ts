interface Person {
    firstName: string;
    lastName: string;
    age: number;
    country: string;
}

export = Person;